import { test, expect, type Page } from "@playwright/test";

// Browsers shorten inset() the way CSS shorthands collapse, so expand back to four sides.
const parseClip = (value: string) => {
  const [top, right = top, bottom = top, left = right] = (value.match(/[\d.]+/g) ?? []).map(Number);
  return [top, right, bottom, left];
};
const clipOf = (page: Page) =>
  page.locator(".story-plane").evaluate((el) => getComputedStyle(el).clipPath).then(parseClip);

test("removes the shutter entirely", async ({ page }) => {
  await page.goto("/fr");
  await expect(page.locator(".shutter, .shutter-slats, .slats")).toHaveCount(0);
  await expect(page.getByText("Ouvrez les persiennes.")).toHaveCount(0);
});

test.describe("scroll story", () => {
  test.beforeEach(async ({ page }) => {
    await page.setViewportSize({ width: 1440, height: 900 });
    await page.goto("/fr");
    await expect(page.locator("html")).not.toHaveAttribute("data-hero-intro", /.+/, { timeout: 3_000 });
    await expect(page.locator(".story")).toHaveAttribute("data-webgl", "true", { timeout: 10_000 });
  });

  const scrollTo = async (page: Page, progress: number) => {
    await page.evaluate((value) => {
      const story = document.querySelector<HTMLElement>(".story")!;
      const top = story.getBoundingClientRect().top + window.scrollY;
      const track = story.offsetHeight - window.innerHeight;
      window.scrollTo({ top: top + track * value, behavior: "instant" });
    }, progress);
    await page.waitForTimeout(900);
  };

  test("uses a five-viewport track", async ({ page }) => {
    const box = await page.locator(".story").boundingBox();
    expect(box!.height).toBe(4500);
  });

  test("reveals the picture from the top down while it widens to the full viewport", async ({ page }) => {
    await scrollTo(page, -0.1);
    const [topA, rightA, bottomA, leftA] = await clipOf(page);
    expect(topA).toBe(0);
    expect(bottomA).toBeGreaterThan(0);
    expect(rightA).toBeGreaterThan(0);
    expect(leftA).toBeCloseTo(rightA, 1);

    await scrollTo(page, 0.04);
    const [topB, rightB, bottomB] = await clipOf(page);
    expect(topB).toBe(0);
    expect(bottomB).toBeLessThan(bottomA);
    expect(rightB).toBeLessThan(rightA);

    await scrollTo(page, 0.25);
    await expect(page.locator(".story-plane")).toHaveCSS("clip-path", "none");
    const plane = await page.locator(".story-plane").boundingBox();
    expect(plane!.width).toBe(1440);
    expect(plane!.height).toBeGreaterThanOrEqual(899);
  });

  test("keeps the picture moving at every stage of the story", async ({ page }) => {
    const shots: Buffer[] = [];
    for (const progress of [0.25, 0.45, 0.6, 0.85, 1]) {
      await scrollTo(page, progress);
      shots.push(await page.locator(".story canvas").screenshot());
    }
    shots.slice(1).forEach((shot, index) => expect(shot.equals(shots[index])).toBe(false));
  });

  test("sizes the canvas before the first frame", async ({ page }) => {
    const size = await page.locator(".story canvas").evaluate((canvas: HTMLCanvasElement) => [canvas.width, canvas.height]);
    expect(size[0]).toBeGreaterThan(0);
    expect(size[1]).toBeGreaterThan(0);
  });

  test("tells the story in three captions, one at a time", async ({ page }) => {
    const gate = page.locator(".story-step").first();
    const path = page.locator(".story-step").last();
    const end = page.locator(".story-caption");

    await scrollTo(page, 0.23);
    await expect(gate).toBeVisible();
    await expect(path).toBeHidden();

    await scrollTo(page, 0.6);
    await expect(gate).toBeHidden();
    await expect(path).toBeVisible();

    await scrollTo(page, 1);
    await expect(path).toBeHidden();
    await expect(end).toBeVisible();
  });
});

test("falls back to the plain photo when WebGL is unavailable", async ({ page }) => {
  await page.addInitScript(() => {
    HTMLCanvasElement.prototype.getContext = () => null;
  });
  await page.goto("/fr");
  await expect(page.locator(".story")).toHaveAttribute("data-animated", "true");
  await expect(page.locator(".story")).not.toHaveAttribute("data-webgl", "true");
  await expect(page.locator(".story canvas")).toBeHidden();
  await expect(page.locator(".story-image")).toBeAttached();
});

test("shows the plain photo under reduced motion", async ({ page }) => {
  await page.emulateMedia({ reducedMotion: "reduce" });
  await page.goto("/fr");
  await expect(page.locator(".story canvas")).toBeHidden();
  await expect(page.locator(".story-image")).toBeVisible();
  await expect(page.locator(".story-step").first()).toBeHidden();
  await expect(page.locator(".story-caption")).toBeVisible();
});
