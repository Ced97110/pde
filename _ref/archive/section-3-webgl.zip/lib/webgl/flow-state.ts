// Share of its segment a photo holds alone before the next one flows in.
const HOLD = 0.75;
const VISIBLE_SPAN = 2 - HOLD;

export interface FlowState {
  from: number;
  to: number;
  mix: number;
  panFrom: number;
  panTo: number;
}

const clamp = (value: number, min: number, max: number) => Math.min(max, Math.max(min, value));

function smoothstep(edge0: number, edge1: number, value: number): number {
  const t = clamp((value - edge0) / (edge1 - edge0), 0, 1);
  return t * t * (3 - 2 * t);
}

function panOf(index: number, position: number): number {
  const visibleFrom = index === 0 ? 0 : index - 1 + HOLD;
  return 1 - clamp((position - visibleFrom) / VISIBLE_SPAN, 0, 1);
}

// Maps scroll progress (0 to 1) to the two photos on screen. Pan 1 is the top of a photo, 0 the bottom.
export function flowState(flow: number, count: number): FlowState {
  const position = clamp(flow, 0, 1) * (count - 1);
  const from = Math.min(Math.floor(position), count - 2);
  const to = from + 1;

  return {
    from,
    to,
    mix: smoothstep(HOLD, 1, position - from),
    panFrom: panOf(from, position),
    panTo: panOf(to, position),
  };
}
