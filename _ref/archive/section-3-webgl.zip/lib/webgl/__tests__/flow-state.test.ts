import { describe, expect, it } from "vitest";
import { flowState } from "../flow-state";

describe("flowState", () => {
  it("starts on the first photo, at the top of it", () => {
    expect(flowState(0, 3)).toEqual({ from: 0, to: 1, mix: 0, panFrom: 1, panTo: 1 });
  });

  it("ends fully on the last photo", () => {
    const state = flowState(1, 3);
    expect(state).toMatchObject({ from: 1, to: 2, mix: 1 });
  });

  it("holds each photo before the next one flows in", () => {
    expect(flowState(0.2, 3).mix).toBe(0);
    expect(flowState(0.45, 3).mix).toBeGreaterThan(0);
  });

  it("pans at a constant speed so the flow never stalls", () => {
    const steps = [0, 0.05, 0.1, 0.15, 0.2].map((flow) => flowState(flow, 3).panFrom);
    const deltas = steps.slice(1).map((pan, index) => steps[index] - pan);
    deltas.forEach((delta) => expect(delta).toBeCloseTo(deltas[0], 5));
    expect(deltas[0]).toBeGreaterThan(0);
  });

  it("clamps values outside the 0 to 1 range", () => {
    expect(flowState(-1, 3)).toEqual(flowState(0, 3));
    expect(flowState(2, 3)).toEqual(flowState(1, 3));
  });
});
