export const VERTEX_SHADER = `#version 300 es
out vec2 vUv;

void main() {
  vec2 corner = vec2((gl_VertexID << 1) & 2, gl_VertexID & 2);
  vUv = corner;
  gl_Position = vec4(corner * 2.0 - 1.0, 0.0, 1.0);
}`;

export const FRAGMENT_SHADER = `#version 300 es
precision highp float;

uniform sampler2D uFrom;
uniform sampler2D uTo;
uniform vec2 uResolution;
uniform vec2 uSizeFrom;
uniform vec2 uSizeTo;
uniform float uMix;
uniform float uPanFrom;
uniform float uPanTo;
uniform float uFlow;
uniform float uVelocity;

in vec2 vUv;
out vec4 fragColor;

const float ZOOM = 1.32;

// Object-fit: cover, zoomed so the photo has room to travel vertically.
vec2 cover(vec2 uv, vec2 size, float pan) {
  float screenRatio = uResolution.x / uResolution.y;
  float imageRatio = size.x / size.y;
  vec2 fit = screenRatio > imageRatio ? vec2(1.0, imageRatio / screenRatio) : vec2(screenRatio / imageRatio, 1.0);
  vec2 scale = fit / ZOOM;
  return uv * scale + vec2((1.0 - scale.x) * 0.5, (1.0 - scale.y) * pan);
}

float waterline(float x, float phase) {
  return sin(x * 5.0 + phase) * 0.035 + sin(x * 11.0 - phase * 1.7) * 0.015;
}

void main() {
  vec2 uv = vUv;
  uv.y += uVelocity * 0.035 * sin(uv.x * 9.0 + uFlow * 40.0);

  // The edge starts above the screen and leaves below it, so the next photo pours downwards.
  float edge = 1.12 - uMix * 1.24 + waterline(uv.x, uFlow * 30.0);
  float distanceToEdge = abs(uv.y - edge);
  float transition = smoothstep(0.0, 0.02, uMix) * (1.0 - smoothstep(0.98, 1.0, uMix));
  float band = (1.0 - smoothstep(0.0, 0.14, distanceToEdge)) * transition;
  float foam = (1.0 - smoothstep(0.0, 0.012, distanceToEdge)) * transition;
  float reveal = smoothstep(edge - 0.012, edge + 0.012, uv.y);

  vec2 refraction = vec2(0.0, band * 0.045);
  vec3 from = texture(uFrom, cover(uv + refraction, uSizeFrom, uPanFrom)).rgb;
  vec3 to = texture(uTo, cover(uv - refraction, uSizeTo, uPanTo)).rgb;

  fragColor = vec4(mix(mix(from, to, reveal), vec3(1.0), foam * 0.45), 1.0);
}`;
