import { flowState } from "./flow-state";
import { FRAGMENT_SHADER, VERTEX_SHADER } from "./flow-shaders";

const MAX_PIXEL_RATIO = 1.5;

export interface FlowFrame {
  flow: number;
  velocity: number;
}

export interface FlowScene {
  draw(frame: FlowFrame): void;
  destroy(): void;
}

interface Photo {
  texture: WebGLTexture;
  width: number;
  height: number;
}

function compile(gl: WebGL2RenderingContext, type: number, source: string): WebGLShader {
  const shader = gl.createShader(type);
  if (!shader) throw new Error("Could not create a shader");
  gl.shaderSource(shader, source);
  gl.compileShader(shader);
  if (!gl.getShaderParameter(shader, gl.COMPILE_STATUS)) {
    throw new Error(gl.getShaderInfoLog(shader) ?? "Shader compilation failed");
  }
  return shader;
}

function createProgram(gl: WebGL2RenderingContext): WebGLProgram {
  const program = gl.createProgram();
  gl.attachShader(program, compile(gl, gl.VERTEX_SHADER, VERTEX_SHADER));
  gl.attachShader(program, compile(gl, gl.FRAGMENT_SHADER, FRAGMENT_SHADER));
  gl.linkProgram(program);
  if (!gl.getProgramParameter(program, gl.LINK_STATUS)) {
    throw new Error(gl.getProgramInfoLog(program) ?? "Shader link failed");
  }
  return program;
}

async function loadPhoto(gl: WebGL2RenderingContext, url: string): Promise<Photo> {
  const image = new Image();
  image.src = url;
  await image.decode();

  const texture = gl.createTexture();
  gl.bindTexture(gl.TEXTURE_2D, texture);
  gl.pixelStorei(gl.UNPACK_FLIP_Y_WEBGL, true);
  gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA, gl.RGBA, gl.UNSIGNED_BYTE, image);
  gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.LINEAR);
  gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_S, gl.CLAMP_TO_EDGE);
  gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_T, gl.CLAMP_TO_EDGE);
  return { texture, width: image.naturalWidth, height: image.naturalHeight };
}

function resize(gl: WebGL2RenderingContext, canvas: HTMLCanvasElement): void {
  const ratio = Math.min(window.devicePixelRatio, MAX_PIXEL_RATIO);
  const width = Math.round(canvas.clientWidth * ratio);
  const height = Math.round(canvas.clientHeight * ratio);
  if (canvas.width === width && canvas.height === height) return;
  canvas.width = width;
  canvas.height = height;
  gl.viewport(0, 0, width, height);
}

// Resolves to null when WebGL2 or a photo is unavailable, so the page keeps its plain image.
export async function createFlowScene(canvas: HTMLCanvasElement, urls: string[]): Promise<FlowScene | null> {
  const gl = canvas.getContext("webgl2", { alpha: false, antialias: false });
  if (!gl) return null;

  try {
    const program = createProgram(gl);
    const photos = await Promise.all(urls.map((url) => loadPhoto(gl, url)));
    const uniform = (name: string) => gl.getUniformLocation(program, name);
    gl.useProgram(program);
    gl.uniform1i(uniform("uFrom"), 0);
    gl.uniform1i(uniform("uTo"), 1);

    const bind = (unit: number, photo: Photo, sizeName: string) => {
      gl.activeTexture(gl.TEXTURE0 + unit);
      gl.bindTexture(gl.TEXTURE_2D, photo.texture);
      gl.uniform2f(uniform(sizeName), photo.width, photo.height);
    };

    return {
      draw({ flow, velocity }) {
        gl.useProgram(program);
        resize(gl, canvas);
        const state = flowState(flow, photos.length);
        bind(0, photos[state.from], "uSizeFrom");
        bind(1, photos[state.to], "uSizeTo");
        gl.uniform2f(uniform("uResolution"), canvas.width, canvas.height);
        gl.uniform1f(uniform("uMix"), state.mix);
        gl.uniform1f(uniform("uPanFrom"), state.panFrom);
        gl.uniform1f(uniform("uPanTo"), state.panTo);
        gl.uniform1f(uniform("uFlow"), flow);
        gl.uniform1f(uniform("uVelocity"), velocity);
        gl.drawArrays(gl.TRIANGLES, 0, 3);
      },
      destroy() {
        photos.forEach((photo) => gl.deleteTexture(photo.texture));
        gl.deleteProgram(program);
      },
    };
  } catch (error) {
    console.error("The WebGL story could not start, keeping the plain photo.", error);
    return null;
  }
}
