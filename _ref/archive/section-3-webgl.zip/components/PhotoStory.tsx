"use client";

import Image from "next/image";
import { useEffect, useRef } from "react";
import { gsap } from "gsap";
import { ScrollTrigger } from "gsap/ScrollTrigger";
import { createFlowScene, type FlowScene } from "@/lib/webgl/flow-scene";

const VELOCITY_RANGE = 3000;
const VELOCITY_SMOOTHING = 0.1;
const START_SIDE_INSET = "30%";

interface StoryProgress {
  flow: number;
}

interface PhotoStoryProps {
  caption: string;
  imageSrc: string;
  imageAlt: string;
  photos: string[];
  steps: [string, string];
}

// Positions are shares of the whole scroll track: the picture opens, then the photos flow.
function buildStory(root: HTMLElement, progress: StoryProgress): gsap.core.Timeline {
  const [gate, path] = gsap.utils.toArray<HTMLElement>(".story-step", root);

  return gsap
    .timeline({
      defaults: { ease: "none" },
      scrollTrigger: { trigger: root, start: "top 70%", end: "bottom bottom", scrub: 0.4 },
    })
    .fromTo(
      ".story-plane",
      { clipPath: `inset(0% ${START_SIDE_INSET} 100% ${START_SIDE_INSET})` },
      { clipPath: "inset(0% 0% 0% 0%)", duration: 0.3 },
      0,
    )
    // A live clip-path forces a mask over the canvas on every frame, even when it clips nothing.
    .set(".story-plane", { clipPath: "none" }, 0.3)
    .to(progress, { flow: 1, duration: 0.9 }, 0.04)
    .fromTo(gate, { autoAlpha: 0 }, { autoAlpha: 1, duration: 0.02 }, 0.31)
    .to(gate, { autoAlpha: 0, duration: 0.02 }, 0.37)
    .fromTo(path, { autoAlpha: 0 }, { autoAlpha: 1, duration: 0.03 }, 0.5)
    .to(path, { autoAlpha: 0, duration: 0.03 }, 0.8)
    .from(".story-caption", { opacity: 0, y: 12, duration: 0.1 }, 0.9);
}

// Draws only when the scroll position or speed changed, so an idle page costs nothing.
function startScene(
  root: HTMLElement,
  timeline: gsap.core.Timeline,
  progress: StoryProgress,
  photos: string[],
): () => void {
  const canvas = root.querySelector("canvas");
  let scene: FlowScene | null = null;
  let stopped = false;
  let velocity = 0;
  let drawnFlow = -1;
  let drawnVelocity = 0;

  const draw = () => {
    if (!scene) return;

    // Not gated on the trigger being active: the last frames settle just after the track ends.
    const speed = timeline.scrollTrigger?.getVelocity() ?? 0;
    const target = gsap.utils.clamp(-1, 1, speed / VELOCITY_RANGE);
    velocity += (target - velocity) * VELOCITY_SMOOTHING;
    if (Math.abs(velocity) < 0.001) velocity = 0;
    if (progress.flow === drawnFlow && velocity === drawnVelocity) return;

    drawnFlow = progress.flow;
    drawnVelocity = velocity;
    scene.draw({ flow: progress.flow, velocity });
  };

  const onContextLost = () => {
    scene = null;
    delete root.dataset.webgl;
  };

  if (canvas) {
    canvas.addEventListener("webglcontextlost", onContextLost);
    void createFlowScene(canvas, photos).then((created) => {
      if (stopped) {
        created?.destroy();
        return;
      }
      if (!created) return;
      scene = created;
      // The canvas has no size until this attribute displays it.
      root.dataset.webgl = "true";
      scene.draw({ flow: progress.flow, velocity: 0 });
    });
  }
  gsap.ticker.add(draw);

  return () => {
    stopped = true;
    gsap.ticker.remove(draw);
    canvas?.removeEventListener("webglcontextlost", onContextLost);
    scene?.destroy();
    delete root.dataset.webgl;
  };
}

export function PhotoStory({ caption, imageSrc, imageAlt, photos, steps }: PhotoStoryProps) {
  const rootRef = useRef<HTMLElement>(null);

  useEffect(() => {
    const root = rootRef.current;
    if (!root) return;

    gsap.registerPlugin(ScrollTrigger);
    const media = gsap.matchMedia();

    media.add("(prefers-reduced-motion: no-preference)", () => {
      root.dataset.animated = "true";
      ScrollTrigger.refresh();

      const progress = { flow: 0 };
      const timeline = buildStory(root, progress);
      const stopScene = startScene(root, timeline, progress, photos);

      return () => {
        stopScene();
        delete root.dataset.animated;
      };
    }, root);

    return () => media.revert();
  }, [photos]);

  return (
    <section ref={rootRef} className="story relative">
      <div className="story-stage relative h-[70svh] overflow-hidden">
        <div className="story-plane absolute inset-0">
          <Image src={imageSrc} alt={imageAlt} fill sizes="100vw" className="story-image object-cover" />
          <canvas aria-hidden="true" className="absolute inset-0 h-full w-full" />
        </div>

        {steps.map((step) => (
          <p key={step} className="story-step story-label absolute">
            {step}
          </p>
        ))}

        <p className="story-caption story-label absolute">{caption}</p>
      </div>
    </section>
  );
}
